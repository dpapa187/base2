import React, { useState, useEffect } from "react";
import { PromptTemplate } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, 
  Copy, 
  Check, 
  Filter,
  BookOpen,
  Zap,
  Target,
  TrendingUp,
  Mail,
  Settings,
  BarChart,
  Globe,
  Users,
  Layers
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const categoryIcons = {
  affiliate_research: Target,
  sales_copy_funnels: Zap,
  social_ads: TrendingUp,
  traffic_generation: Globe,
  email_marketing: Mail,
  conversion_optimization: BarChart,
  seo_content: Search,
  product_creation: Layers,
  automation: Settings,
  community_building: Users
};

const categoryLabels = {
  affiliate_research: "Affiliate Research",
  sales_copy_funnels: "Sales Copy & Funnels",
  social_ads: "Social & Ads",
  traffic_generation: "Traffic Generation",
  email_marketing: "Email Marketing",
  conversion_optimization: "Conversion Optimization",
  seo_content: "SEO Content",
  product_creation: "Product Creation",
  automation: "Automation",
  community_building: "Community Building"
};

export default function PromptLibrary() {
  const [prompts, setPrompts] = useState([]);
  const [filteredPrompts, setFilteredPrompts] = useState([]);
  const [selectedPrompt, setSelectedPrompt] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const [copiedPrompt, setCopiedPrompt] = useState(null);
  const [customizedPrompt, setCustomizedPrompt] = useState('');

  useEffect(() => {
    loadPrompts();
  }, []);

  useEffect(() => {
    filterPrompts();
  }, [prompts, searchTerm, selectedCategory, selectedDifficulty]);

  const loadPrompts = async () => {
    setIsLoading(true);
    try {
      const data = await PromptTemplate.list();
      setPrompts(data);
    } catch (error) {
      console.error("Error loading prompts:", error);
    }
    setIsLoading(false);
  };

  const filterPrompts = () => {
    let filtered = prompts;

    if (searchTerm) {
      filtered = filtered.filter(prompt => 
        prompt.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prompt.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prompt.tags?.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(prompt => prompt.category === selectedCategory);
    }

    if (selectedDifficulty !== 'all') {
      filtered = filtered.filter(prompt => prompt.difficulty === selectedDifficulty);
    }

    setFilteredPrompts(filtered);
  };

  const copyPrompt = (prompt) => {
    navigator.clipboard.writeText(prompt.prompt_text);
    setCopiedPrompt(prompt.id);
    setTimeout(() => setCopiedPrompt(null), 2000);
  };

  const customizePrompt = (prompt) => {
    setSelectedPrompt(prompt);
    setCustomizedPrompt(prompt.prompt_text);
  };

  const groupedPrompts = filteredPrompts.reduce((acc, prompt) => {
    if (!acc[prompt.category]) {
      acc[prompt.category] = [];
    }
    acc[prompt.category].push(prompt);
    return acc;
  }, {});

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-yellow-400/20 text-yellow-400 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <BookOpen className="w-4 h-4" />
            Professional Prompts
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Prompt Library
            <span className="gradient-text block">For Affiliates</span>
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Battle-tested prompts for affiliate marketing success. Copy, customize, and dominate your niche.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar Filters */}
          <div className="lg:col-span-1">
            <Card className="glass-effect border-white/10 text-white sticky top-4">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Filter className="w-5 h-5 text-yellow-400" />
                  Filters
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Search */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Search</label>
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input
                      placeholder="Search prompts..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                    />
                  </div>
                </div>

                {/* Category */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Category</label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="bg-white/10 border-white/20 text-white">
                      <SelectValue placeholder="All Categories" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-900 border-white/20">
                      <SelectItem value="all" className="text-white">All Categories</SelectItem>
                      {Object.entries(categoryLabels).map(([key, label]) => (
                        <SelectItem key={key} value={key} className="text-white">
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Difficulty */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Difficulty</label>
                  <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                    <SelectTrigger className="bg-white/10 border-white/20 text-white">
                      <SelectValue placeholder="All Levels" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-900 border-white/20">
                      <SelectItem value="all" className="text-white">All Levels</SelectItem>
                      <SelectItem value="beginner" className="text-white">Beginner</SelectItem>
                      <SelectItem value="intermediate" className="text-white">Intermediate</SelectItem>
                      <SelectItem value="advanced" className="text-white">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Stats */}
                <div className="pt-4 border-t border-white/10">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Prompts</span>
                      <span className="text-white font-medium">{prompts.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Filtered</span>
                      <span className="text-yellow-400 font-medium">{filteredPrompts.length}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {selectedPrompt ? (
              <PromptCustomizer 
                prompt={selectedPrompt}
                customizedPrompt={customizedPrompt}
                setCustomizedPrompt={setCustomizedPrompt}
                onBack={() => setSelectedPrompt(null)}
              />
            ) : (
              <div className="space-y-6">
                {isLoading ? (
                  <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {Array(9).fill(0).map((_, i) => (
                      <Card key={i} className="glass-effect border-white/10 animate-pulse">
                        <CardContent className="p-6">
                          <div className="h-4 bg-white/10 rounded mb-3"></div>
                          <div className="h-3 bg-white/10 rounded mb-2"></div>
                          <div className="h-3 bg-white/10 rounded mb-4"></div>
                          <div className="h-8 bg-white/10 rounded"></div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : filteredPrompts.length === 0 ? (
                  <Card className="glass-effect border-white/10 text-white">
                    <CardContent className="p-12 text-center">
                      <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold mb-2">No prompts found</h3>
                      <p className="text-gray-400">Try adjusting your search or filters</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                    <AnimatePresence>
                      {filteredPrompts.map((prompt, index) => (
                        <motion.div
                          key={prompt.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -20 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <Card className="glass-effect border-white/10 text-white h-full hover:border-yellow-400/50 transition-all duration-300">
                            <CardHeader className="pb-3">
                              <div className="flex items-start justify-between">
                                <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 mb-2">
                                  {categoryLabels[prompt.category] || prompt.category}
                                </Badge>
                                {prompt.difficulty && (
                                  <Badge className={`text-xs ${
                                    prompt.difficulty === 'beginner' ? 'bg-green-500/20 text-green-400' :
                                    prompt.difficulty === 'intermediate' ? 'bg-yellow-400/20 text-yellow-400' :
                                    'bg-red-500/20 text-red-400'
                                  }`}>
                                    {prompt.difficulty}
                                  </Badge>
                                )}
                              </div>
                              <CardTitle className="text-lg leading-tight">{prompt.title}</CardTitle>
                            </CardHeader>
                            <CardContent className="pt-0 flex flex-col flex-1">
                              <p className="text-gray-300 text-sm mb-4 flex-1">
                                {prompt.description}
                              </p>
                              <div className="flex gap-2">
                                <Button 
                                  variant="outline"
                                  size="sm"
                                  onClick={() => copyPrompt(prompt)}
                                  className="flex-1 border-white/20 text-white hover:bg-white/10"
                                >
                                  {copiedPrompt === prompt.id ? (
                                    <>
                                      <Check className="w-3 h-3 mr-2" />
                                      Copied!
                                    </>
                                  ) : (
                                    <>
                                      <Copy className="w-3 h-3 mr-2" />
                                      Copy
                                    </>
                                  )}
                                </Button>
                                <Button 
                                  size="sm"
                                  onClick={() => customizePrompt(prompt)}
                                  className="flex-1 bg-yellow-400 hover:bg-yellow-500 text-black"
                                >
                                  <Settings className="w-3 h-3 mr-2" />
                                  Customize
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Prompt Customizer Component
function PromptCustomizer({ prompt, customizedPrompt, setCustomizedPrompt, onBack }) {
  const [variables, setVariables] = useState({});
  const [finalPrompt, setFinalPrompt] = useState('');

  useEffect(() => {
    if (prompt.variables) {
      const initialVars = {};
      prompt.variables.forEach(variable => {
        initialVars[variable] = '';
      });
      setVariables(initialVars);
    }
  }, [prompt]);

  useEffect(() => {
    let result = customizedPrompt;
    Object.entries(variables).forEach(([key, value]) => {
      if (value) {
        const regex = new RegExp(`\\[${key}\\]`, 'g');
        result = result.replace(regex, value);
      }
    });
    setFinalPrompt(result);
  }, [customizedPrompt, variables]);

  const copyFinalPrompt = () => {
    navigator.clipboard.writeText(finalPrompt);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" onClick={onBack} className="border-white/20 text-white hover:bg-white/10">
          ← Back to Library
        </Button>
        <div>
          <h2 className="text-2xl font-bold text-white">{prompt.title}</h2>
          <p className="text-gray-300">{prompt.description}</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Variables Input */}
        <Card className="glass-effect border-white/10 text-white">
          <CardHeader>
            <CardTitle>Customize Variables</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {prompt.variables?.map((variable) => (
              <div key={variable} className="space-y-2">
                <label className="text-sm font-medium text-gray-300 capitalize">
                  {variable.replace(/_/g, ' ')}
                </label>
                <Input
                  value={variables[variable] || ''}
                  onChange={(e) => setVariables(prev => ({
                    ...prev,
                    [variable]: e.target.value
                  }))}
                  placeholder={`Enter ${variable.replace(/_/g, ' ')}`}
                  className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                />
              </div>
            ))}
            
            <div className="pt-4">
              <label className="text-sm font-medium text-gray-300">Raw Prompt Template</label>
              <Textarea
                value={customizedPrompt}
                onChange={(e) => setCustomizedPrompt(e.target.value)}
                className="mt-2 bg-white/10 border-white/20 text-white h-32"
              />
            </div>
          </CardContent>
        </Card>

        {/* Final Output */}
        <Card className="glass-effect border-white/10 text-white">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Final Prompt
              <Button 
                onClick={copyFinalPrompt}
                className="bg-yellow-400 hover:bg-yellow-500 text-black"
              >
                <Copy className="w-4 h-4 mr-2" />
                Copy Final
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={finalPrompt}
              readOnly
              className="bg-gray-900 border-white/20 text-gray-300 h-64"
              placeholder="Your customized prompt will appear here..."
            />
            
            <div className="mt-4 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <h4 className="font-semibold text-blue-400 mb-2">💡 Usage Tips</h4>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• Copy this prompt to ChatGPT, Claude, or your AI tool</li>
                <li>• Ask for 3 variations and pick the best</li>
                <li>• Request "tighten + polish" for final version</li>
                <li>• For ads, always ask for "policy-safe rewrite"</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}