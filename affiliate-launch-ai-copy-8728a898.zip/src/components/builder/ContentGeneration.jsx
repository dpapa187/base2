import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, Zap, Wand2 } from "lucide-react";
import { motion } from "framer-motion";

export default function ContentGeneration({ 
  projectData,
  generatedContent,
  setGeneratedContent,
  isGenerating,
  setIsGenerating,
  onNext,
  onPrev,
  currentStep,
  totalSteps 
}) {
  
  const handleGenerate = async () => {
    setIsGenerating(true);
    
    // Simulate content generation
    setTimeout(() => {
      const mockContent = {
        headline: `Revolutionary ${projectData.keyword} Solution That Actually Works!`,
        subheadline: `Discover the proven system that's helped thousands achieve their ${projectData.keyword} goals faster than ever before.`,
        hero_content: `Are you tired of struggling with ${projectData.keyword}? You're not alone. Millions of people face the same challenges every day, but there's finally a solution that works.\n\nIntroducing the breakthrough system that's changing everything in the ${projectData.category} industry.`,
        benefits: [
          `Fast ${projectData.keyword} results`,
          "Easy to follow system",
          "Scientifically proven method",
          "Money-back guarantee",
          "24/7 support included"
        ],
        main_content: `This isn't just another ${projectData.keyword} program. This is a complete transformation system backed by real science and proven results.\n\nHere's what makes this different:\n\nOur proprietary method combines the latest research with time-tested strategies to deliver results faster than you ever thought possible.\n\nThousands of people have already transformed their lives using this exact system.`,
        testimonials: [
          {
            name: "Sarah Johnson",
            text: "I couldn't believe the results! This system changed everything for me.",
            rating: 5
          },
          {
            name: "Mike Chen",
            text: "Finally, something that actually works. Highly recommended!",
            rating: 5
          }
        ],
        cta_text: "Don't wait another day to start your transformation. Join thousands who have already succeeded.",
        footer_content: "© 2024 - All rights reserved. Results may vary."
      };
      
      setGeneratedContent(mockContent);
      setIsGenerating(false);
    }, 3000);
  };

  return (
    <Card className="glass-effect border-white/10 text-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-yellow-400" />
          AI Content Generation
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {!generatedContent ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center space-y-6"
          >
            <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto">
              <Wand2 className="w-8 h-8 text-purple-400" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-white mb-4">Ready to Generate Your Content</h3>
              <p className="text-gray-300 mb-6">
                Our AI will create a complete landing page with headlines, copy, benefits, testimonials, and more.
              </p>
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-6">
                <h4 className="font-semibold text-blue-400 mb-2">📋 Project Summary</h4>
                <div className="text-sm text-gray-300 space-y-1">
                  <p><span className="text-gray-400">Title:</span> {projectData.title}</p>
                  <p><span className="text-gray-400">Keyword:</span> {projectData.keyword}</p>
                  <p><span className="text-gray-400">Category:</span> {projectData.category}</p>
                  <p><span className="text-gray-400">Type:</span> {projectData.page_type}</p>
                  <p><span className="text-gray-400">Length:</span> {projectData.content_length} words</p>
                </div>
              </div>
              <Button 
                onClick={handleGenerate}
                disabled={isGenerating}
                className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white font-semibold px-8 py-3"
              >
                {isGenerating ? (
                  <>
                    <Zap className="w-4 h-4 mr-2 animate-spin" />
                    Generating Content...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4 mr-2" />
                    Generate AI Content
                  </>
                )}
              </Button>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
              <h4 className="font-semibold text-green-400 mb-2">✅ Content Generated Successfully!</h4>
              <p className="text-sm text-gray-300">Your landing page content is ready for preview.</p>
            </div>
            
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-white mb-2">Headline</h4>
                <p className="text-gray-300 bg-white/5 p-3 rounded-lg">{generatedContent.headline}</p>
              </div>
              
              <div>
                <h4 className="font-semibold text-white mb-2">Subheadline</h4>
                <p className="text-gray-300 bg-white/5 p-3 rounded-lg">{generatedContent.subheadline}</p>
              </div>
              
              <div>
                <h4 className="font-semibold text-white mb-2">Key Benefits</h4>
                <div className="bg-white/5 p-3 rounded-lg">
                  <ul className="text-gray-300 space-y-1">
                    {generatedContent.benefits?.map((benefit, index) => (
                      <li key={index}>• {benefit}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </CardContent>

      {/* Navigation */}
      <div className="flex justify-between p-6 border-t border-white/10">
        <Button 
          variant="outline"
          onClick={onPrev}
          className="border-white/20 text-white hover:bg-white/10"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Setup
        </Button>
        
        {generatedContent && (
          <Button 
            onClick={onNext}
            className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-semibold"
          >
            Preview Page
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        )}
      </div>
    </Card>
  );
}