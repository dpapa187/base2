import React, { useState } from "react";
import { LandingPage } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

import ProjectSetup from "../components/builder/ProjectSetup";
import ContentGeneration from "../components/builder/ContentGeneration";
import PagePreview from "../components/builder/PagePreview";
import ExportOptions from "../components/builder/ExportOptions";

export default function Builder() {
  const [currentStep, setCurrentStep] = useState(1);
  const [projectData, setProjectData] = useState({
    title: "",
    page_type: "landing",
    affiliate_network: "clickbank",
    category: "",
    keyword: "",
    affiliate_url: "",
    content_length: 3000
  });
  const [generatedContent, setGeneratedContent] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const steps = [
    { id: 1, name: "Setup", component: ProjectSetup },
    { id: 2, name: "Generate", component: ContentGeneration },
    { id: 3, name: "Preview", component: PagePreview },
    { id: 4, name: "Export", component: ExportOptions }
  ];

  const handleNext = () => {
    setCurrentStep(prev => Math.min(prev + 1, steps.length));
  };

  const handlePrev = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const handleProjectUpdate = (updates) => {
    setProjectData(prev => ({ ...prev, ...updates }));
  };

  const CurrentStepComponent = steps[currentStep - 1].component;

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="icon" className="border-white/20 text-white hover:bg-white/10">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-white">Landing Page Builder</h1>
              <p className="text-gray-300">Create high-converting pages with AI</p>
            </div>
          </div>
        </div>

        {/* Progress Steps */}
        <Card className="glass-effect border-white/10 mb-8">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              {steps.map((step, index) => (
                <div key={step.id} className="flex items-center">
                  <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                    currentStep >= step.id 
                      ? "bg-yellow-400 border-yellow-400 text-black" 
                      : "border-white/30 text-gray-400"
                  }`}>
                    {step.id}
                  </div>
                  <span className={`ml-3 font-medium ${
                    currentStep >= step.id ? "text-white" : "text-gray-400"
                  }`}>
                    {step.name}
                  </span>
                  {index < steps.length - 1 && (
                    <div className={`w-16 h-0.5 ml-6 ${
                      currentStep > step.id ? "bg-yellow-400" : "bg-white/20"
                    }`} />
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Step Content */}
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
        >
          <CurrentStepComponent
            projectData={projectData}
            onProjectUpdate={handleProjectUpdate}
            generatedContent={generatedContent}
            setGeneratedContent={setGeneratedContent}
            isGenerating={isGenerating}
            setIsGenerating={setIsGenerating}
            onNext={handleNext}
            onPrev={handlePrev}
            currentStep={currentStep}
            totalSteps={steps.length}
          />
        </motion.div>
      </div>
    </div>
  );
}