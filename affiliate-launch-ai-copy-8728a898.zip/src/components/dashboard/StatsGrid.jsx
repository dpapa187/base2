import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, CheckCircle, Clock, Type } from "lucide-react";
import { motion } from "framer-motion";

export default function StatsGrid({ stats, isLoading }) {
  const statItems = [
    {
      title: "Total Pages",
      value: stats.totalPages,
      icon: FileText,
      color: "text-blue-400"
    },
    {
      title: "Completed",
      value: stats.completedPages,
      icon: CheckCircle,
      color: "text-green-400"
    },
    {
      title: "Generating",
      value: stats.generatingPages,
      icon: Clock,
      color: "text-yellow-400"
    },
    {
      title: "Total Words",
      value: stats.totalWords.toLocaleString(),
      icon: Type,
      color: "text-purple-400"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statItems.map((item, index) => (
        <motion.div
          key={item.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card className="glass-effect border-white/10 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">{item.title}</p>
                  <p className="text-2xl font-bold">
                    {isLoading ? "..." : item.value}
                  </p>
                </div>
                <item.icon className={`w-8 h-8 ${item.color}`} />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}