import { base44 } from './base44Client';


export const LandingPage = base44.entities.LandingPage;

export const UserSettings = base44.entities.UserSettings;

export const PromptTemplate = base44.entities.PromptTemplate;



// auth sdk:
export const User = base44.auth;