import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Eye, Download, Plus, RefreshCw } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { motion } from "framer-motion";

const statusColors = {
  draft: "bg-gray-500/20 text-gray-300",
  generating: "bg-yellow-400/20 text-yellow-400", 
  complete: "bg-green-500/20 text-green-400"
};

export default function RecentPages({ pages, isLoading, onRefresh }) {
  return (
    <Card className="glass-effect border-white/10 text-white">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-yellow-400" />
            Recent Pages
          </CardTitle>
          <Button 
            variant="outline"
            size="sm"
            onClick={onRefresh}
            className="border-white/20 text-white hover:bg-white/10"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {isLoading ? (
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="flex items-center justify-between p-4 border border-white/10 rounded-lg">
                <div className="space-y-2">
                  <div className="h-4 bg-white/10 rounded w-48"></div>
                  <div className="h-3 bg-white/10 rounded w-32"></div>
                </div>
                <div className="h-6 bg-white/10 rounded w-16"></div>
              </div>
            </div>
          ))
        ) : pages.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="w-6 h-6 text-gray-400" />
            </div>
            <h3 className="font-semibold text-gray-300 mb-2">No pages yet</h3>
            <p className="text-gray-400 text-sm mb-4">Create your first landing page to get started</p>
            <Link to={createPageUrl("Builder")}>
              <Button className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-semibold">
                <Plus className="w-4 h-4 mr-2" />
                Create Page
              </Button>
            </Link>
          </div>
        ) : (
          pages.slice(0, 5).map((page, index) => (
            <motion.div
              key={page.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center justify-between p-4 border border-white/10 rounded-lg hover:bg-white/5 transition-colors"
            >
              <div className="flex-1">
                <h4 className="font-medium text-white">{page.title}</h4>
                <div className="flex items-center gap-2 mt-1">
                  <Badge className={statusColors[page.status]}>
                    {page.status}
                  </Badge>
                  <span className="text-sm text-gray-400">
                    {format(new Date(page.created_date), "MMM d")}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white hover:bg-white/10">
                  <Eye className="w-4 h-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  disabled={!page.html_export}
                  className="text-gray-400 hover:text-white hover:bg-white/10 disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          ))
        )}
      </CardContent>
    </Card>
  );
}