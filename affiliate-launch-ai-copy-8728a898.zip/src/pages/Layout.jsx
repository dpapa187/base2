
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Zap, 
  LayoutDashboard, 
  Plus, 
  Settings,
  FileText,
  Eye,
  Download,
  BookOpen
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
  },
  {
    title: "Create Page",
    url: createPageUrl("Builder"),
    icon: Plus,
  },
  {
    title: "Prompt Library",
    url: createPageUrl("PromptLibrary"),
    icon: BookOpen,
  },
  {
    title: "My Pages",
    url: createPageUrl("Pages"),
    icon: FileText,
  },
  {
    title: "Settings",
    url: createPageUrl("Settings"),
    icon: Settings,
  }
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <style>{`
        :root {
          --primary-gradient: linear-gradient(135deg, #581c87, #1e3a8a, #312e81);
          --gold: #facc15;
          --purple-600: #9333ea;
          --purple-700: #7c3aed;
          --blue-600: #2563eb;
        }
        
        .glass-effect {
          background: rgba(255, 255, 255, 0.1);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .gradient-text {
          background: linear-gradient(135deg, #facc15, #f59e0b);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
      `}</style>
      
      <SidebarProvider>
        <div className="min-h-screen flex w-full">
          <Sidebar className="border-r border-white/10 bg-black/20 backdrop-blur-xl">
            <SidebarHeader className="border-b border-white/10 p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl flex items-center justify-center">
                  <Zap className="w-6 h-6 text-black" />
                </div>
                <div>
                  <h2 className="font-bold text-white text-lg">LandingAI Pro</h2>
                  <p className="text-xs text-gray-300">Affiliate Landing Generator</p>
                </div>
              </div>
            </SidebarHeader>
            
            <SidebarContent className="p-2">
              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-medium text-gray-400 uppercase tracking-wider px-2 py-2">
                  Navigation
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {navigationItems.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton 
                          asChild 
                          className={`hover:bg-white/10 hover:text-yellow-400 transition-all duration-300 rounded-xl mb-1 ${
                            location.pathname === item.url ? 'bg-white/10 text-yellow-400' : 'text-gray-300'
                          }`}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                            <item.icon className="w-5 h-5" />
                            <span className="font-medium">{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>

              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-medium text-gray-400 uppercase tracking-wider px-2 py-2">
                  Quick Actions
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <div className="px-3 py-2 space-y-3">
                    <Link 
                      to={createPageUrl("Builder")}
                      className="flex items-center gap-2 text-sm text-gray-300 hover:text-yellow-400 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      <span>New Landing Page</span>
                    </Link>
                    <div className="flex items-center gap-2 text-sm text-gray-400">
                      <Eye className="w-4 h-4" />
                      <span>Preview Mode</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-400">
                      <Download className="w-4 h-4" />
                      <span>Export HTML</span>
                    </div>
                  </div>
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>

            <SidebarFooter className="border-t border-white/10 p-4">
              <div className="bg-gradient-to-r from-yellow-400/20 to-orange-500/20 rounded-xl p-3">
                <p className="text-sm font-medium text-yellow-400">🚀 Pro Version</p>
                <p className="text-xs text-gray-300 mt-1">Unlimited AI generations</p>
              </div>
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 flex flex-col">
            <header className="bg-black/20 backdrop-blur-xl border-b border-white/10 px-6 py-4 md:hidden">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="hover:bg-white/10 p-2 rounded-lg transition-colors duration-200 text-white" />
                <h1 className="text-xl font-semibold text-white">LandingAI Pro</h1>
              </div>
            </header>

            <div className="flex-1 overflow-auto">
              {children}
            </div>
          </main>
        </div>
      </SidebarProvider>
    </div>
  );
}
