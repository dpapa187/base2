import React, { useState } from 'react';
import { LandingPage } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Download, Check, Copy, Globe, Zap } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ExportOptions({ 
  projectData, 
  generatedContent,
  onPrev
}) {
  const [exportedHtml, setExportedHtml] = useState('');
  const [isExporting, setIsExporting] = useState(false);
  const [isExported, setIsExported] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  const generateHtmlExport = () => {
    const htmlTemplate = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${generatedContent.headline}</title>
    <meta name="description" content="${generatedContent.subheadline}">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .gradient-bg { background: linear-gradient(135deg, #3b82f6, #8b5cf6); }
        .cta-gradient { background: linear-gradient(135deg, #fbbf24, #f59e0b); }
    </style>
</head>
<body class="font-sans">
    <!-- Header -->
    <header class="gradient-bg text-white py-16 px-8">
        <div class="max-w-4xl mx-auto text-center">
            <h1 class="text-4xl md:text-6xl font-bold mb-4">
                ${generatedContent.headline}
            </h1>
            <p class="text-xl mb-8 opacity-90">
                ${generatedContent.subheadline}
            </p>
            ${generatedContent.images?.[0] ? `
            <img src="${generatedContent.images[0]}" alt="Hero" class="mx-auto rounded-lg shadow-2xl max-w-md w-full">
            ` : ''}
        </div>
    </header>

    <!-- Hero Content -->
    <section class="py-16 px-8">
        <div class="max-w-4xl mx-auto">
            ${generatedContent.hero_content?.split('\n').map(p => `<p class="mb-4 text-gray-700 leading-relaxed">${p}</p>`).join('') || ''}
        </div>
    </section>

    <!-- Benefits -->
    ${generatedContent.benefits ? `
    <section class="py-16 px-8 bg-gray-50">
        <div class="max-w-4xl mx-auto">
            <h2 class="text-3xl font-bold text-center mb-12">Key Benefits</h2>
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                ${generatedContent.benefits.map(benefit => `
                <div class="text-center p-6 bg-white rounded-lg shadow-md">
                    <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <span class="text-blue-600 text-xl">⭐</span>
                    </div>
                    <p class="font-medium">${benefit}</p>
                </div>
                `).join('')}
            </div>
        </div>
    </section>
    ` : ''}

    <!-- Main Content -->
    <section class="py-16 px-8">
        <div class="max-w-4xl mx-auto">
            ${generatedContent.main_content?.split('\n').map(p => `<p class="mb-4 text-gray-700 leading-relaxed">${p}</p>`).join('') || ''}
        </div>
    </section>

    <!-- Testimonials -->
    ${generatedContent.testimonials ? `
    <section class="py-16 px-8 bg-gray-50">
        <div class="max-w-4xl mx-auto">
            <h2 class="text-3xl font-bold text-center mb-12">What People Say</h2>
            <div class="grid md:grid-cols-2 gap-8">
                ${generatedContent.testimonials.map(testimonial => `
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <div class="flex items-center mb-4">
                        ${'⭐'.repeat(testimonial.rating || 5)}
                    </div>
                    <p class="text-gray-700 mb-4">"${testimonial.text}"</p>
                    <p class="font-semibold text-gray-900">- ${testimonial.name}</p>
                </div>
                `).join('')}
            </div>
        </div>
    </section>
    ` : ''}

    <!-- CTA Section -->
    <section class="py-16 px-8 bg-gradient-to-r from-green-600 to-blue-600 text-white text-center">
        <div class="max-w-2xl mx-auto">
            <h2 class="text-3xl font-bold mb-6">Ready to Get Started?</h2>
            <p class="text-xl mb-8 opacity-90">${generatedContent.cta_text}</p>
            <a href="${projectData.affiliate_url || '#'}" target="_blank" 
               class="inline-block bg-yellow-400 hover:bg-yellow-500 text-black font-bold px-12 py-4 text-lg rounded-full transition-colors">
                Get Instant Access Now
            </a>
            <p class="text-sm mt-4 opacity-75">30-day money-back guarantee</p>
        </div>
    </section>

    <!-- Footer -->
    <footer class="py-8 px-8 bg-gray-800 text-white text-center">
        <p class="text-gray-400">${generatedContent.footer_content}</p>
    </footer>
</body>
</html>`;

    return htmlTemplate;
  };

  const handleExport = async () => {
    setIsExporting(true);
    
    try {
      const htmlCode = generateHtmlExport();
      setExportedHtml(htmlCode);
      
      // Save to database
      await LandingPage.create({
        ...projectData,
        generated_content: JSON.stringify(generatedContent),
        html_export: htmlCode,
        status: 'complete'
      });
      
      setIsExported(true);
    } catch (error) {
      console.error("Export error:", error);
    }
    
    setIsExporting(false);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(exportedHtml);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const downloadHtml = () => {
    const blob = new Blob([exportedHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${projectData.title.toLowerCase().replace(/\s+/g, '-')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleFinish = () => {
    window.location.href = createPageUrl("Dashboard");
  };

  return (
    <div className="space-y-8">
      <Card className="glass-effect border-white/10 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="w-5 h-5 text-yellow-400" />
            Export & Deploy
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {!isExported ? (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center space-y-6"
            >
              <div className="w-16 h-16 bg-yellow-400/20 rounded-full flex items-center justify-center mx-auto">
                <Globe className="w-8 h-8 text-yellow-400" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white mb-4">Ready to Deploy Your Landing Page</h3>
                <p className="text-gray-300 mb-6">
                  Generate production-ready HTML code that you can deploy anywhere
                </p>
                <div className="grid md:grid-cols-3 gap-4 mb-8">
                  <div className="p-4 bg-white/5 rounded-lg">
                    <h4 className="font-semibold text-white mb-2">📁 Netlify</h4>
                    <p className="text-sm text-gray-400">Drag & drop deployment</p>
                  </div>
                  <div className="p-4 bg-white/5 rounded-lg">
                    <h4 className="font-semibold text-white mb-2">🚀 Render</h4>
                    <p className="text-sm text-gray-400">Static site hosting</p>
                  </div>
                  <div className="p-4 bg-white/5 rounded-lg">
                    <h4 className="font-semibold text-white mb-2">⚡ Vercel</h4>
                    <p className="text-sm text-gray-400">Fast global CDN</p>
                  </div>
                </div>
                <Button 
                  onClick={handleExport}
                  disabled={isExporting}
                  className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-semibold px-8 py-3"
                >
                  {isExporting ? (
                    <>
                      <Zap className="w-4 h-4 mr-2 animate-spin" />
                      Generating HTML...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      Generate HTML Export
                    </>
                  )}
                </Button>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="text-center">
                <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Check className="w-8 h-8 text-green-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Export Complete!</h3>
                <p className="text-gray-300">Your landing page is ready for deployment</p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-white">HTML Code</h4>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline"
                      size="sm"
                      onClick={copyToClipboard}
                      className="border-white/20 text-white hover:bg-white/10"
                    >
                      {isCopied ? (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copy Code
                        </>
                      )}
                    </Button>
                    <Button 
                      variant="outline"
                      size="sm"
                      onClick={downloadHtml}
                      className="border-white/20 text-white hover:bg-white/10"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download HTML
                    </Button>
                  </div>
                </div>
                <Textarea
                  value={exportedHtml}
                  readOnly
                  className="bg-gray-900 border-white/20 text-gray-300 font-mono text-sm h-64"
                  placeholder="Generated HTML will appear here..."
                />
              </div>

              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                <h4 className="font-semibold text-blue-400 mb-2">🚀 Deployment Instructions</h4>
                <ol className="text-sm text-gray-300 space-y-1">
                  <li>1. Download the HTML file</li>
                  <li>2. Upload to your hosting provider (Netlify, Render, Vercel)</li>
                  <li>3. Set up your custom domain</li>
                  <li>4. Update your affiliate links if needed</li>
                </ol>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between">
        <Button 
          variant="outline"
          onClick={onPrev}
          className="border-white/20 text-white hover:bg-white/10"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Preview
        </Button>
        
        {isExported && (
          <Button 
            onClick={handleFinish}
            className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-semibold"
          >
            <Check className="w-4 h-4 mr-2" />
            Finish & Go to Dashboard
          </Button>
        )}
      </div>
    </div>
  );
}