import React, { useState, useEffect } from "react";
import { UserSettings } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings as SettingsIcon, Key, Globe, Save, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function Settings() {
  const [settings, setSettings] = useState({
    openai_api_key: '',
    anthropic_api_key: '',
    preferred_ai_provider: 'openai',
    default_content_length: 3000,
    affiliate_networks: {
      jvzoo_id: '',
      warriorplus_id: '',
      clickbank_id: ''
    }
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState('');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setIsLoading(true);
    try {
      const user = await User.me();
      const userSettings = await UserSettings.filter({ created_by: user.email });
      if (userSettings.length > 0) {
        setSettings(userSettings[0]);
      }
    } catch (error) {
      console.error("Error loading settings:", error);
    }
    setIsLoading(false);
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveMessage('');
    
    try {
      const user = await User.me();
      const existingSettings = await UserSettings.filter({ created_by: user.email });
      
      if (existingSettings.length > 0) {
        await UserSettings.update(existingSettings[0].id, settings);
      } else {
        await UserSettings.create(settings);
      }
      
      setSaveMessage('Settings saved successfully!');
      setTimeout(() => setSaveMessage(''), 3000);
    } catch (error) {
      console.error("Error saving settings:", error);
      setSaveMessage('Error saving settings. Please try again.');
    }
    
    setIsSaving(false);
  };

  const handleInputChange = (field, value) => {
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      setSettings(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: value
        }
      }));
    } else {
      setSettings(prev => ({
        ...prev,
        [field]: value
      }));
    }
  };

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-white mb-2">Settings</h1>
          <p className="text-gray-300">Configure your API keys and preferences</p>
        </motion.div>

        {/* Save Message */}
        {saveMessage && (
          <Alert className={`mb-6 ${saveMessage.includes('Error') ? 'border-red-500 bg-red-500/10' : 'border-green-500 bg-green-500/10'}`}>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className={saveMessage.includes('Error') ? 'text-red-400' : 'text-green-400'}>
              {saveMessage}
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="api" className="space-y-6">
          <TabsList className="bg-white/10 text-white">
            <TabsTrigger value="api" className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black">
              <Key className="w-4 h-4 mr-2" />
              API Keys
            </TabsTrigger>
            <TabsTrigger value="preferences" className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black">
              <SettingsIcon className="w-4 h-4 mr-2" />
              Preferences
            </TabsTrigger>
            <TabsTrigger value="affiliate" className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black">
              <Globe className="w-4 h-4 mr-2" />
              Affiliate Networks
            </TabsTrigger>
          </TabsList>

          <TabsContent value="api">
            <Card className="glass-effect border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="w-5 h-5 text-yellow-400" />
                  API Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <Alert className="border-yellow-400/50 bg-yellow-400/10">
                  <AlertCircle className="h-4 w-4 text-yellow-400" />
                  <AlertDescription className="text-yellow-200">
                    Your API keys are encrypted and stored securely. They're only used for content generation.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="openai_api_key" className="text-gray-300">OpenAI API Key</Label>
                    <Input
                      id="openai_api_key"
                      type="password"
                      value={settings.openai_api_key}
                      onChange={(e) => handleInputChange('openai_api_key', e.target.value)}
                      placeholder="sk-..."
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                    />
                    <p className="text-xs text-gray-400">Get your key from platform.openai.com</p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="anthropic_api_key" className="text-gray-300">Anthropic API Key</Label>
                    <Input
                      id="anthropic_api_key"
                      type="password"
                      value={settings.anthropic_api_key}
                      onChange={(e) => handleInputChange('anthropic_api_key', e.target.value)}
                      placeholder="sk-ant-..."
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                    />
                    <p className="text-xs text-gray-400">Get your key from console.anthropic.com</p>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-gray-300">Preferred AI Provider</Label>
                    <Select 
                      value={settings.preferred_ai_provider} 
                      onValueChange={(value) => handleInputChange('preferred_ai_provider', value)}
                    >
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue placeholder="Select provider" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-900 border-white/20">
                        <SelectItem value="openai" className="text-white">OpenAI (GPT-4)</SelectItem>
                        <SelectItem value="anthropic" className="text-white">Anthropic (Claude)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="preferences">
            <Card className="glass-effect border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <SettingsIcon className="w-5 h-5 text-yellow-400" />
                  Content Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label className="text-gray-300">Default Content Length</Label>
                  <Select 
                    value={settings.default_content_length?.toString()} 
                    onValueChange={(value) => handleInputChange('default_content_length', parseInt(value))}
                  >
                    <SelectTrigger className="bg-white/10 border-white/20 text-white">
                      <SelectValue placeholder="Select length" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-900 border-white/20">
                      <SelectItem value="1500" className="text-white">1,500 words (Short)</SelectItem>
                      <SelectItem value="3000" className="text-white">3,000 words (Medium)</SelectItem>
                      <SelectItem value="5000" className="text-white">5,000 words (Long)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="affiliate">
            <Card className="glass-effect border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5 text-yellow-400" />
                  Affiliate Network IDs
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <Alert className="border-blue-400/50 bg-blue-400/10">
                  <AlertCircle className="h-4 w-4 text-blue-400" />
                  <AlertDescription className="text-blue-200">
                    These IDs will be automatically inserted into your affiliate links when generating pages.
                  </AlertDescription>
                </Alert>

                <div className="grid md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="clickbank_id" className="text-gray-300">ClickBank ID</Label>
                    <Input
                      id="clickbank_id"
                      value={settings.affiliate_networks?.clickbank_id || ''}
                      onChange={(e) => handleInputChange('affiliate_networks.clickbank_id', e.target.value)}
                      placeholder="yourusername"
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="jvzoo_id" className="text-gray-300">JVZoo ID</Label>
                    <Input
                      id="jvzoo_id"
                      value={settings.affiliate_networks?.jvzoo_id || ''}
                      onChange={(e) => handleInputChange('affiliate_networks.jvzoo_id', e.target.value)}
                      placeholder="yourusername"
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="warriorplus_id" className="text-gray-300">WarriorPlus ID</Label>
                    <Input
                      id="warriorplus_id"
                      value={settings.affiliate_networks?.warriorplus_id || ''}
                      onChange={(e) => handleInputChange('affiliate_networks.warriorplus_id', e.target.value)}
                      placeholder="yourusername"
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Save Button */}
        <div className="flex justify-end mt-8">
          <Button 
            onClick={handleSave}
            disabled={isSaving}
            className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-semibold px-8 py-3"
          >
            {isSaving ? (
              <>
                <SettingsIcon className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Save Settings
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}