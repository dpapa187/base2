import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ArrowRight, Eye, Star } from "lucide-react";
import { motion } from "framer-motion";

export default function PagePreview({ 
  projectData,
  generatedContent,
  onNext,
  onPrev,
  currentStep,
  totalSteps 
}) {
  
  if (!generatedContent) {
    return (
      <Card className="glass-effect border-white/10 text-white">
        <CardContent className="p-12 text-center">
          <h3 className="text-xl font-semibold text-gray-300 mb-2">No content to preview</h3>
          <p className="text-gray-400">Please generate content first</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-8">
      <Card className="glass-effect border-white/10 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-yellow-400" />
            Page Preview
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Preview Content */}
          <div className="max-w-4xl mx-auto">
            {/* Hero Section Preview */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8 rounded-lg mb-8"
            >
              <div className="text-center">
                <h1 className="text-3xl md:text-5xl font-bold mb-4">
                  {generatedContent.headline}
                </h1>
                <p className="text-xl mb-6 opacity-90">
                  {generatedContent.subheadline}
                </p>
                <div className="w-32 h-32 bg-white/20 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <span className="text-sm">Hero Image</span>
                </div>
              </div>
            </motion.div>

            {/* Content Sections */}
            <div className="space-y-8">
              {/* Hero Content */}
              <section className="bg-white/5 p-6 rounded-lg">
                <h2 className="text-xl font-semibold text-white mb-4">Introduction</h2>
                <div className="text-gray-300 leading-relaxed">
                  {generatedContent.hero_content?.split('\n').map((paragraph, index) => (
                    <p key={index} className="mb-4">{paragraph}</p>
                  ))}
                </div>
              </section>

              {/* Benefits */}
              {generatedContent.benefits && (
                <section className="bg-white/5 p-6 rounded-lg">
                  <h2 className="text-xl font-semibold text-white mb-6">Key Benefits</h2>
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {generatedContent.benefits.map((benefit, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="text-center p-4 bg-white/5 rounded-lg"
                      >
                        <div className="w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center mx-auto mb-3">
                          <Star className="w-4 h-4 text-black" />
                        </div>
                        <p className="text-gray-300">{benefit}</p>
                      </motion.div>
                    ))}
                  </div>
                </section>
              )}

              {/* Main Content */}
              <section className="bg-white/5 p-6 rounded-lg">
                <h2 className="text-xl font-semibold text-white mb-4">Main Content</h2>
                <div className="text-gray-300 leading-relaxed">
                  {generatedContent.main_content?.split('\n').map((paragraph, index) => (
                    <p key={index} className="mb-4">{paragraph}</p>
                  ))}
                </div>
              </section>

              {/* Testimonials */}
              {generatedContent.testimonials && (
                <section className="bg-white/5 p-6 rounded-lg">
                  <h2 className="text-xl font-semibold text-white mb-6">Testimonials</h2>
                  <div className="grid md:grid-cols-2 gap-6">
                    {generatedContent.testimonials.map((testimonial, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.2 }}
                        className="bg-white/5 p-4 rounded-lg"
                      >
                        <div className="flex items-center mb-3">
                          {Array(testimonial.rating || 5).fill(0).map((_, i) => (
                            <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                          ))}
                        </div>
                        <p className="text-gray-300 italic mb-3">"{testimonial.text}"</p>
                        <p className="font-semibold text-white">- {testimonial.name}</p>
                      </motion.div>
                    ))}
                  </div>
                </section>
              )}

              {/* CTA Section */}
              <section className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-8 rounded-lg text-center">
                <h2 className="text-2xl font-bold mb-4">Ready to Get Started?</h2>
                <p className="text-lg mb-6 opacity-90">{generatedContent.cta_text}</p>
                <Button className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold px-8 py-4 text-lg rounded-full">
                  Get Instant Access Now
                </Button>
                <p className="text-sm mt-4 opacity-75">30-day money-back guarantee</p>
              </section>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between">
        <Button 
          variant="outline"
          onClick={onPrev}
          className="border-white/20 text-white hover:bg-white/10"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Generate
        </Button>
        
        <Button 
          onClick={onNext}
          className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-semibold"
        >
          Export Page
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}