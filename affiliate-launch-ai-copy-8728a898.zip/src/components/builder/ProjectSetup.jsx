import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ArrowRight, Settings } from "lucide-react";

export default function ProjectSetup({ 
  projectData, 
  onProjectUpdate, 
  onNext,
  currentStep,
  totalSteps 
}) {
  const handleInputChange = (field, value) => {
    onProjectUpdate({ [field]: value });
  };

  const isFormValid = () => {
    return projectData.title && projectData.keyword && projectData.category;
  };

  return (
    <Card className="glass-effect border-white/10 text-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="w-5 h-5 text-yellow-400" />
          Project Setup
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-gray-300">Page Title *</Label>
            <Input
              id="title"
              value={projectData.title}
              onChange={(e) => handleInputChange('title', e.target.value)}
              placeholder="e.g., Weight Loss Landing Page"
              className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="keyword" className="text-gray-300">Main Keyword *</Label>
            <Input
              id="keyword"
              value={projectData.keyword}
              onChange={(e) => handleInputChange('keyword', e.target.value)}
              placeholder="e.g., weight loss"
              className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-gray-300">Page Type</Label>
            <Select 
              value={projectData.page_type} 
              onValueChange={(value) => handleInputChange('page_type', value)}
            >
              <SelectTrigger className="bg-white/10 border-white/20 text-white">
                <SelectValue placeholder="Select page type" />
              </SelectTrigger>
              <SelectContent className="bg-gray-900 border-white/20">
                <SelectItem value="landing" className="text-white">Landing Page</SelectItem>
                <SelectItem value="advertorial" className="text-white">Advertorial</SelectItem>
                <SelectItem value="optin" className="text-white">Opt-in Page</SelectItem>
                <SelectItem value="blog" className="text-white">Blog Style</SelectItem>
                <SelectItem value="vsl" className="text-white">Video Sales Letter</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-gray-300">Affiliate Network</Label>
            <Select 
              value={projectData.affiliate_network} 
              onValueChange={(value) => handleInputChange('affiliate_network', value)}
            >
              <SelectTrigger className="bg-white/10 border-white/20 text-white">
                <SelectValue placeholder="Select network" />
              </SelectTrigger>
              <SelectContent className="bg-gray-900 border-white/20">
                <SelectItem value="clickbank" className="text-white">ClickBank</SelectItem>
                <SelectItem value="jvzoo" className="text-white">JVZoo</SelectItem>
                <SelectItem value="warriorplus" className="text-white">WarriorPlus</SelectItem>
                <SelectItem value="other" className="text-white">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="category" className="text-gray-300">Category/Niche *</Label>
          <Input
            id="category"
            value={projectData.category}
            onChange={(e) => handleInputChange('category', e.target.value)}
            placeholder="e.g., Health & Fitness"
            className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="affiliate_url" className="text-gray-300">Affiliate URL</Label>
          <Input
            id="affiliate_url"
            value={projectData.affiliate_url}
            onChange={(e) => handleInputChange('affiliate_url', e.target.value)}
            placeholder="https://your-affiliate-link.com"
            className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-gray-300">Content Length</Label>
          <Select 
            value={projectData.content_length?.toString()} 
            onValueChange={(value) => handleInputChange('content_length', parseInt(value))}
          >
            <SelectTrigger className="bg-white/10 border-white/20 text-white">
              <SelectValue placeholder="Select length" />
            </SelectTrigger>
            <SelectContent className="bg-gray-900 border-white/20">
              <SelectItem value="1500" className="text-white">1,500 words (Short)</SelectItem>
              <SelectItem value="3000" className="text-white">3,000 words (Medium)</SelectItem>
              <SelectItem value="5000" className="text-white">5,000 words (Long)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex justify-end">
          <Button 
            onClick={onNext}
            disabled={!isFormValid()}
            className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-semibold"
          >
            Next Step
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}