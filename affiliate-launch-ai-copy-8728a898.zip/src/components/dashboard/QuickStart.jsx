import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Zap, 
  BookOpen, 
  Settings, 
  Plus,
  ArrowRight
} from "lucide-react";
import { motion } from "framer-motion";

export default function QuickStart() {
  const quickActions = [
    {
      title: "Create Landing Page",
      description: "Generate a high-converting page in minutes",
      icon: Plus,
      url: createPageUrl("Builder"),
      color: "bg-gradient-to-r from-yellow-400 to-orange-500"
    },
    {
      title: "Browse Prompts",
      description: "Professional prompts for affiliate marketing", 
      icon: BookOpen,
      url: createPageUrl("PromptLibrary"),
      color: "bg-gradient-to-r from-blue-500 to-purple-500"
    },
    {
      title: "Setup API Keys",
      description: "Configure AI providers for content generation",
      icon: Settings,
      url: createPageUrl("Settings"),
      color: "bg-gradient-to-r from-green-500 to-teal-500"
    }
  ];

  return (
    <Card className="glass-effect border-white/10 text-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-yellow-400" />
          Quick Start
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {quickActions.map((action, index) => (
          <motion.div
            key={action.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Link to={action.url}>
              <div className="p-4 border border-white/10 rounded-lg hover:bg-white/5 transition-all duration-300 group cursor-pointer">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg ${action.color} flex items-center justify-center`}>
                      <action.icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-white group-hover:text-yellow-400 transition-colors">
                        {action.title}
                      </h4>
                      <p className="text-sm text-gray-400">
                        {action.description}
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-yellow-400 transition-colors" />
                </div>
              </div>
            </Link>
          </motion.div>
        ))}

        <div className="mt-6 p-4 bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-lg border border-purple-500/20">
          <h4 className="font-semibold text-purple-400 mb-2">💡 Pro Tips</h4>
          <ul className="text-sm text-gray-300 space-y-1">
            <li>• Start with proven prompts from the library</li>
            <li>• Use clear, benefit-focused headlines</li>
            <li>• Always include social proof</li>
            <li>• Test different page layouts</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}