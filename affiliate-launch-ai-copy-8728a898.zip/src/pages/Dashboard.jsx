import React, { useState, useEffect } from "react";
import { LandingPage } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Plus, 
  FileText, 
  Eye, 
  Download,
  Zap,
  TrendingUp,
  Clock,
  DollarSign
} from "lucide-react";
import { motion } from "framer-motion";

import StatsGrid from "../components/dashboard/StatsGrid";
import RecentPages from "../components/dashboard/RecentPages";
import QuickStart from "../components/dashboard/QuickStart";

export default function Dashboard() {
  const [pages, setPages] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPages();
  }, []);

  const loadPages = async () => {
    setIsLoading(true);
    try {
      const data = await LandingPage.list("-created_date", 10);
      setPages(data);
    } catch (error) {
      console.error("Error loading pages:", error);
    }
    setIsLoading(false);
  };

  const stats = {
    totalPages: pages.length,
    completedPages: pages.filter(p => p.status === 'complete').length,
    generatingPages: pages.filter(p => p.status === 'generating').length,
    totalWords: pages.reduce((sum, p) => sum + (p.content_length || 0), 0)
  };

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-yellow-400/20 text-yellow-400 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Zap className="w-4 h-4" />
            AI-Powered Landing Pages
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Create High-Converting
            <span className="gradient-text block">Affiliate Landing Pages</span>
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Generate professional landing pages in minutes using advanced AI. 
            Perfect for ClickBank, JVZoo, and WarriorPlus affiliate marketing.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("Builder")}>
              <Button className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-semibold px-8 py-4 text-lg rounded-xl">
                <Plus className="w-5 h-5 mr-2" />
                Create Landing Page
              </Button>
            </Link>
            <Link to={createPageUrl("Pages")}>
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 px-8 py-4 text-lg rounded-xl">
                <FileText className="w-5 h-5 mr-2" />
                View My Pages
              </Button>
            </Link>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <StatsGrid 
          stats={stats}
          isLoading={isLoading}
        />

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-8 mt-12">
          {/* Recent Pages */}
          <div className="lg:col-span-2">
            <RecentPages 
              pages={pages}
              isLoading={isLoading}
              onRefresh={loadPages}
            />
          </div>

          {/* Quick Start */}
          <div>
            <QuickStart />
          </div>
        </div>

        {/* Features Grid */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-16"
        >
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            Everything You Need to Succeed
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Zap,
                title: "AI Content Generation",
                description: "GPT-4 & Claude powered content creation"
              },
              {
                icon: Eye,
                title: "Live Preview",
                description: "See your pages as you build them"
              },
              {
                icon: Download,
                title: "HTML Export",
                description: "Deploy anywhere with clean HTML"
              },
              {
                icon: DollarSign,
                title: "Affiliate Ready",
                description: "Built for ClickBank, JVZoo & more"
              }
            ].map((feature, index) => (
              <Card key={index} className="glass-effect border-white/10 text-white">
                <CardContent className="p-6 text-center">
                  <feature.icon className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-300 text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}