import React, { useState, useEffect } from "react";
import { LandingPage } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Search, 
  Filter, 
  Plus, 
  Eye, 
  Download, 
  Edit, 
  Trash2,
  FileText,
  RefreshCw
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";

const statusColors = {
  draft: "bg-gray-500/20 text-gray-300 border-gray-500/30",
  generating: "bg-yellow-400/20 text-yellow-400 border-yellow-400/30",
  complete: "bg-green-500/20 text-green-400 border-green-500/30"
};

const pageTypeLabels = {
  landing: "Landing Page",
  advertorial: "Advertorial",
  optin: "Opt-in Page",
  blog: "Blog Style",
  vsl: "Video Sales Letter"
};

export default function Pages() {
  const [pages, setPages] = useState([]);
  const [filteredPages, setFilteredPages] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  useEffect(() => {
    loadPages();
  }, []);

  useEffect(() => {
    filterPages();
  }, [pages, searchTerm, statusFilter, typeFilter]);

  const loadPages = async () => {
    setIsLoading(true);
    try {
      const data = await LandingPage.list("-created_date");
      setPages(data);
    } catch (error) {
      console.error("Error loading pages:", error);
    }
    setIsLoading(false);
  };

  const filterPages = () => {
    let filtered = pages;

    if (searchTerm) {
      filtered = filtered.filter(page => 
        page.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        page.keyword.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(page => page.status === statusFilter);
    }

    if (typeFilter !== 'all') {
      filtered = filtered.filter(page => page.page_type === typeFilter);
    }

    setFilteredPages(filtered);
  };

  const downloadHtml = (page) => {
    if (!page.html_export) return;
    
    const blob = new Blob([page.html_export], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${page.title.toLowerCase().replace(/\s+/g, '-')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4"
        >
          <div>
            <h1 className="text-3xl font-bold text-white">My Landing Pages</h1>
            <p className="text-gray-300">Manage and export your AI-generated pages</p>
          </div>
          <Link to={createPageUrl("Builder")}>
            <Button className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-semibold">
              <Plus className="w-4 h-4 mr-2" />
              Create New Page
            </Button>
          </Link>
        </motion.div>

        {/* Filters */}
        <Card className="glass-effect border-white/10 mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Search pages..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                  />
                </div>
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40 bg-white/10 border-white/20 text-white">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-white/20">
                  <SelectItem value="all" className="text-white">All Status</SelectItem>
                  <SelectItem value="draft" className="text-white">Draft</SelectItem>
                  <SelectItem value="generating" className="text-white">Generating</SelectItem>
                  <SelectItem value="complete" className="text-white">Complete</SelectItem>
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-40 bg-white/10 border-white/20 text-white">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-white/20">
                  <SelectItem value="all" className="text-white">All Types</SelectItem>
                  <SelectItem value="landing" className="text-white">Landing Page</SelectItem>
                  <SelectItem value="advertorial" className="text-white">Advertorial</SelectItem>
                  <SelectItem value="optin" className="text-white">Opt-in Page</SelectItem>
                  <SelectItem value="blog" className="text-white">Blog Style</SelectItem>
                  <SelectItem value="vsl" className="text-white">VSL</SelectItem>
                </SelectContent>
              </Select>
              <Button 
                variant="outline" 
                size="icon"
                onClick={loadPages}
                className="border-white/20 text-white hover:bg-white/10"
              >
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Pages Table */}
        <Card className="glass-effect border-white/10 text-white">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-yellow-400" />
                Landing Pages ({filteredPages.length})
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {Array(5).fill(0).map((_, i) => (
                  <div key={i} className="animate-pulse flex items-center justify-between p-4 border border-white/10 rounded-lg">
                    <div className="space-y-2">
                      <div className="h-4 bg-white/10 rounded w-48"></div>
                      <div className="h-3 bg-white/10 rounded w-32"></div>
                    </div>
                    <div className="h-6 bg-white/10 rounded w-16"></div>
                  </div>
                ))}
              </div>
            ) : filteredPages.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <FileText className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-300 mb-2">
                  {pages.length === 0 ? "No pages yet" : "No pages match your filters"}
                </h3>
                <p className="text-gray-400 mb-6">
                  {pages.length === 0 ? "Create your first AI-powered landing page" : "Try adjusting your search or filters"}
                </p>
                <Link to={createPageUrl("Builder")}>
                  <Button className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-semibold">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Landing Page
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-white/10 hover:bg-white/5">
                      <TableHead className="text-gray-300">Title</TableHead>
                      <TableHead className="text-gray-300">Type</TableHead>
                      <TableHead className="text-gray-300">Status</TableHead>
                      <TableHead className="text-gray-300">Network</TableHead>
                      <TableHead className="text-gray-300">Created</TableHead>
                      <TableHead className="text-gray-300">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <AnimatePresence>
                      {filteredPages.map((page, index) => (
                        <motion.tr
                          key={page.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 20 }}
                          transition={{ delay: index * 0.05 }}
                          className="border-white/10 hover:bg-white/5"
                        >
                          <TableCell>
                            <div>
                              <p className="font-medium text-white">{page.title}</p>
                              <p className="text-sm text-gray-400">{page.keyword}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="border-white/20 text-gray-300">
                              {pageTypeLabels[page.page_type]}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className={statusColors[page.status]}>
                              {page.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-gray-300 capitalize">
                            {page.affiliate_network}
                          </TableCell>
                          <TableCell className="text-gray-300">
                            {format(new Date(page.created_date), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="text-gray-400 hover:text-white hover:bg-white/10"
                                title="Preview"
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="text-gray-400 hover:text-white hover:bg-white/10"
                                title="Edit"
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => downloadHtml(page)}
                                disabled={!page.html_export}
                                className="text-gray-400 hover:text-white hover:bg-white/10 disabled:opacity-50"
                                title="Download HTML"
                              >
                                <Download className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </motion.tr>
                      ))}
                    </AnimatePresence>
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}